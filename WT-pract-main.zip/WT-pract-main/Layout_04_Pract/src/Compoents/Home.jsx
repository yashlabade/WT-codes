import React, { useState } from 'react'

function Home() {
    return(
        <>
        <h2 className='head'> Home Page</h2>
        <p className='para'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore, laborum culpa magnam et praesentium dolorum atque nihil animi omnis cupiditate magni delectus iste tempore possimus qui natus nobis nam dolore labore. Delectus ex reprehenderit corrupti sint cupiditate maiores, commodi natus atque, sunt, ea vitae non. Hic magni commodi totam incidunt voluptatum, praesentium dolores quibusdam qui velit amet minus ab pariatur soluta, unde fuga? Omnis quidem illo nisi non rem ipsam, architecto ipsa voluptatibus assumenda animi ab hic repellendus quod repudiandae error quas natus itaque amet maiores blanditiis. Recusandae, possimus corporis asperiores, maiores eveniet laboriosam, dicta eligendi molestiae accusamus nihil nesciunt!</p>
        </>
    )
}

export default Home