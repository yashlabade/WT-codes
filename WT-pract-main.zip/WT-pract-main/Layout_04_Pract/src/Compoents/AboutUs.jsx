import React, { useState } from 'react'

function AboutUs() {
    return(
        <>
        <h2 className='head'>About Page</h2>
        <p className='para'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus reprehenderit necessitatibus, dicta unde tempora ut odit saepe laboriosam sunt enim dolorum optio libero voluptates quidem harum accusamus ad minus. Aliquam, nisi? Ratione officia architecto illo repudiandae earum, tenetur iure itaque dolore cumque in cupiditate nam sint fugiat debitis mollitia quam eaque voluptatum perferendis error dignissimos doloribus doloremque soluta? Est explicabo, rem doloremque distinctio magnam necessitatibus porro adipisci hic quo eius aliquid debitis eligendi maiores cupiditate magni incidunt temporibus iure minima voluptatem repellat velit. Expedita sint nisi ducimus et quisquam blanditiis similique, sapiente error cupiditate animi perferendis, minima esse explicabo, assumenda voluptate? Quisquam, dignissimos! Expedita, ipsum quasi! Voluptates fuga sunt blanditiis iste nulla commodi quis modi, impedit placeat soluta ipsum, eaque neque nemo sit consequatur exercitationem? Earum fugit quia ratione nostrum provident vitae iste consectetur corrupti labore repellendus, aperiam repellat. Sed culpa, veritatis architecto ea rerum reiciendis eum doloribus vel. Delectus.</p>
        </>
    )
}

export default AboutUs