import React from 'react';

function Footer() {
  return (
    <footer className="footer">
      <p className='Heading'>© 2024 All rights reserved.</p>
    </footer>
  );
}

export default Footer;
