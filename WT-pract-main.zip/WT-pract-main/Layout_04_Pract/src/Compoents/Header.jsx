import React, { useState } from 'react'
import './EachPage.css';

function Header() {
    return(
        <>
        <h1 className='Heading'>This Webpage is created using React </h1>
        </>
    )
}

export default Header