import Contact from "./components/Contact";
import Home from "./Home";

function Content({ pageName }) {
    if (pageName == "Home") {


        return (
            <>
                <Home/>
            </>
        )
    }

    if (pageName == "Contact") {


        return (
            <>
                <Contact/>
            </>
        )
    }
}
export default Content;