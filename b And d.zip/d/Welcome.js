import React from 'react';
import Welcome from './Welcome';

const App = () => {
  return <Welcome name="Harshal" />;
};

export default App;
