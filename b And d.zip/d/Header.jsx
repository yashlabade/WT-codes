import './css/header.css'
function Header() {
    return (
        <>
            <div className='Header'>
                <h4>Welcome To React</h4>
            </div>
        </>
    );
}
export default Header;