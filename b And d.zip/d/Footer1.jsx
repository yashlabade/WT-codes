import './css/footer.css';
function Footer1() {
    return (
        <>
            <div className='Footer1'>
               <marquee><h1>This is Footer of website</h1></marquee> 
            </div>
        </>
    )

}
export default Footer1;