function sum(a, b) {
    return a + b;
}

// Example usage:
let num1 = 2;
let num2 = 3;
let result = sum(num1, num2);
console.log("The sum is: " + result);
