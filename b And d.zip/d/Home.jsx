import "./css/Home.css";
function Home(){
    return(
        <>
        <h2 className="hm">
        When designing or developing a Home Module for a website, this typically refers to the homepage or the main dashboard. The home module plays a crucial role as it is the entry point of a website, giving users their first impression and easy access to other parts of the site. Here’s a detailed breakdown of the important elements to consider</h2>
        </>
    )
}
export default Home;