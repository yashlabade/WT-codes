import "./css/Home.css";  
function Contact(){
    return(
        <>
        <h2 className="hm">An About Module for a website is a key section that provides visitors with insight into the identity, mission, and values of the company, organization, or individual behind the site. It's typically designed to build trust, establish credibility, and help users understand the purpose of the website. Here's a breakdown of the important elements that make a compelling About Module:</h2>
        </>
    )
}
export default Contact;